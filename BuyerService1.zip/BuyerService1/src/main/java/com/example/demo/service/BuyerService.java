package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.example.demo.Buyer;
import com.example.demo.Product;
import com.example.demo.repositry.BuyerDao;
import com.example.demo.repositry.UserDao;

@Service
public class BuyerService {
	@Autowired
	public BuyerDao bydao;
	@Autowired
	public UserDao usdao;

	public List<Product> getProducts()
	{
		
		return  bydao.findAll();
	}

	public String addProduct(Buyer buyer) {
		// TODO Auto-generated method stub
		 usdao.save( buyer);
		return "/User Added/";
	}

	public List<Buyer> getUsers() {
		// TODO Auto-generated method stub
		return usdao.findAll();
	}

}
