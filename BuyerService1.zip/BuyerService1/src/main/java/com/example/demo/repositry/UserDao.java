package com.example.demo.repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Buyer;
import com.example.demo.Product;

public interface UserDao extends JpaRepository<Buyer, Integer>
{

}
