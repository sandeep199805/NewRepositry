package com.example.demo;

import java.util.List;

import javax.persistence.*;

@Entity
public class ShoppingCart {
@Id
private int cart_Id;
/*@OneToMany//(mappedBy = "cart")
private  List<Product> product;*/
private int quantity;
private float total_price;
@ManyToOne
private Buyer user;








public int getQuantity() {
	return quantity;
}


public void setQuantity(int quantity) {
	this.quantity = quantity;
}


public Buyer getUser() {
	return user;
}


public void setUser(Buyer user) {
	this.user = user;
}


//productId
public ShoppingCart() {
	System.out.println("ShoppingCart Object Has been Created");
}






public ShoppingCart(int cart_Id, List<Product> product, int quantity, float total_price, Buyer user) {
	super();
	this.cart_Id = cart_Id;
	//this.product = product;
	this.quantity = quantity;
	this.total_price = total_price;
	this.user = user;
}


@Override
public String toString() {
	return "ShoppingCart [cart_Id=" + cart_Id + ", quantity=" + quantity + ", total_price="
			+ total_price + ", user=" + user + "]";
}


public int getCart_Id() {
	return cart_Id;
}

public void setCart_Id(int cart_Id) {
	this.cart_Id = cart_Id;
}
public int getQuatity() {
	return quantity;
}
public void setQuatity(int quantity) {
	this.quantity = quantity;
}
public float getTotal_price() {
	return total_price;
}
public void setTotal_price(float total_price) {
	this.total_price = total_price;
}

}
