package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Buyer;
import com.example.demo.repositry.BuyerRepo;
@Service
public class BuyerService {
	@Autowired
	public BuyerRepo buyerrepo;

	public List<Buyer> getAllUsers() 
	{
		// TODO Auto-generated method stub
		return buyerrepo.findAll();
	}

}
